# Fasal Setu - Cold Chain AI (demo web app)
Run (Python 3.8+, no installs): `python server.py` then open http://localhost:8000
Demo: create batch -> watch live temp -> "Simulate AC failure" -> L1/L2/L3 alerts + siren (click "Enable siren sound" first) -> shelf-life countdown drops -> "Sell-or-Store AI".
Live data: `DATA_GOV_KEY=<key> python server.py` (data.gov.in Agmarknet prices; verify resource/fields in their docs). Weather: Open-Meteo, no key.
Real sensors: replace tick() in server.py with MQTT/HTTP readings from ESP32 and write into the `readings` table.

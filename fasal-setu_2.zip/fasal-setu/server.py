"""Fasal Setu - zero-dependency full-stack demo (Python stdlib + SQLite). Run: python server.py"""
import json, sqlite3, threading, time, os, random, urllib.request, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
ROOT = os.path.dirname(os.path.abspath(__file__))
# crop: (ideal_min C, ideal_max C, base shelf-life days, fallback price Rs/kg)
CROPS = {"Banana": (12, 14, 14, 22), "Tomato": (10, 13, 10, 18), "Mango": (10, 13, 12, 60),
         "Grapes": (0, 2, 20, 70), "Potato": (4, 7, 60, 16)}
MSG = {1: "Temperature drifting out of range", 2: "Temperature HIGH - SMS/WhatsApp sent to farmer",
       3: "CRITICAL - siren ON, storage owner called, backup storage suggested"}
db = sqlite3.connect(os.path.join(ROOT, "fasal.db"), check_same_thread=False); db.row_factory = sqlite3.Row
L = threading.Lock(); S = {"fault": False, "off": 0.0}
db.executescript("""create table if not exists batches(id integer primary key, code text, crop text, qty real,
farmer text, consumed real default 0, temp real, level int default 0, created real);
create table if not exists readings(id integer primary key, bid int, ts real, temp real);
create table if not exists alerts(id integer primary key, bid int, ts real, level int, msg text);""")

def add_batch(crop, qty, farmer):
    lo, hi = CROPS[crop][:2]
    db.execute("insert into batches(code,crop,qty,farmer,temp,created) values(?,?,?,?,?,?)",
               ("FS-%04d" % random.randint(0, 9999), crop, qty, farmer, (lo + hi) / 2, time.time())); db.commit()
if not db.execute("select 1 from batches").fetchone(): add_batch("Banana", 500, "Ramesh (Nagpur)")

def tick():  # 1 tick = 4 simulated hours of ageing
    with L:
        S["off"] = min(12, S["off"] + 1.2) if S["fault"] else max(0, S["off"] - 1.5)
        for b in db.execute("select * from batches").fetchall():
            lo, hi, days, _ = CROPS[b["crop"]]; mid = (lo + hi) / 2
            t = b["temp"] + (mid + S["off"] - b["temp"]) * 0.4 + random.uniform(-.2, .2)
            c = min(1, b["consumed"] + 4 / (days * 24) * (2 ** ((t - hi) / 5) if t > hi else 1))
            dev = max(0, t - hi, lo - t); lvl = 3 if dev > 6 else 2 if dev > 3.5 else 1 if dev > 1.5 else 0
            if lvl > b["level"]: db.execute("insert into alerts(bid,ts,level,msg) values(?,?,?,?)", (b["id"], time.time(), lvl, MSG[lvl]))
            db.execute("update batches set consumed=?,temp=?,level=? where id=?", (c, t, lvl, b["id"]))
            db.execute("insert into readings(bid,ts,temp) values(?,?,?)", (b["id"], time.time(), t))
        db.execute("delete from readings where ts<?", (time.time() - 600,)); db.commit()

def loop():
    while True:
        try: tick()
        except Exception as e: print("tick error", e)
        time.sleep(2)

def state():
    with L:
        out = []
        for b in db.execute("select * from batches order by id desc").fetchall():
            lo, hi, days, _ = CROPS[b["crop"]]
            h = [r["temp"] for r in db.execute("select temp from readings where bid=? order by id desc limit 40", (b["id"],))][::-1]
            out.append(dict(id=b["id"], code=b["code"], crop=b["crop"], qty=b["qty"], farmer=b["farmer"], temp=b["temp"],
                            level=b["level"], range=[lo, hi], remaining_days=round(days * (1 - b["consumed"]), 1),
                            life_pct=round(100 * (1 - b["consumed"])), history=h))
        al = [dict(r) for r in db.execute("select a.*,b.code from alerts a join batches b on b.id=a.bid order by a.id desc limit 10")]
        return dict(batches=out, alerts=al, fault=S["fault"], maxlevel=max([b["level"] for b in out] or [0]))

def live_price(crop):  # optional: set DATA_GOV_KEY (free key from data.gov.in) for real Agmarknet mandi prices
    key = os.environ.get("DATA_GOV_KEY")
    if not key: return None, "demo price (set DATA_GOV_KEY for live Agmarknet)"
    try:
        q = urllib.parse.urlencode({"api-key": key, "format": "json", "limit": 5, "filters[commodity]": crop})
        u = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070?" + q
        rec = json.load(urllib.request.urlopen(u, timeout=6))["records"][0]
        return float(rec["modal_price"]) / 100, "live Agmarknet: %s mandi" % rec.get("market", "?")
    except Exception: return None, "demo price (Agmarknet fetch failed)"

def advice(bid):
    with L: b = db.execute("select * from batches where id=?", (bid,)).fetchone()
    if not b: return {"error": "not found"}
    lo, hi, days, base = CROPS[b["crop"]]; rem = days * (1 - b["consumed"])
    p, src = live_price(b["crop"]); p = p or base
    hold = int(min(5, max(0, rem - 1))); exp = p * (1 + 0.015 * hold)
    risk = min(.95, .04 * hold + .5 * b["consumed"] + .1 * b["level"])
    sell = p * b["qty"]; store = (exp * (1 - risk) - 0.3 * hold) * b["qty"]
    if rem < 2: d, why = "DISTRESS SALE", "Life < 2 days: offer to juice/pulp unit or NGO now (Rs %.0f/kg) instead of losing it." % (p * .8)
    elif store > sell: d, why = "STORE %d days" % hold, "Expected Rs %.1f/kg after %d days, spoilage risk %d%%." % (exp, hold, risk * 100)
    else: d, why = "SELL NOW", "Holding adds spoilage risk (%d%%) and cost; net gain is lower." % (risk * 100)
    return dict(decision=d, reason=why, price=round(p, 1), price_source=src, net_sell=round(sell), net_store=round(store), remaining_days=round(rem, 1))

def weather(lat, lon):
    try:
        u = "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max&forecast_days=2" % (lat, lon)
        return json.load(urllib.request.urlopen(u, timeout=6))
    except Exception: return {"error": "weather unavailable"}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, obj, ct="application/json", code=200):
        b = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path == "/api/state": self.out(state())
        elif u.path == "/api/advice": self.out(advice(int(q.get("id", [0])[0])))
        elif u.path == "/api/weather": self.out(weather(q.get("lat", ["21.1458"])[0], q.get("lon", ["79.0882"])[0]))
        else: self.out(open(os.path.join(ROOT, "static", "index.html"), "rb").read(), "text/html; charset=utf-8")
    def do_POST(self):
        d = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        with L:
            if self.path == "/api/batches" and d.get("crop") in CROPS: add_batch(d["crop"], float(d.get("qty") or 100), d.get("farmer") or "Farmer")
            elif self.path == "/api/fault": S["fault"] = bool(d.get("on"))
            elif self.path == "/api/reset": S.update(fault=False, off=0.0); db.execute("update batches set consumed=0,level=0"); db.commit()
        self.out({"ok": True})

if __name__ == "__main__":
    threading.Thread(target=loop, daemon=True).start()
    print("Fasal Setu running on http://localhost:8000"); ThreadingHTTPServer(("0.0.0.0", 8000), H).serve_forever()
